<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::resource('/painel/produtos', 'Painel\ProdutoController');

Route::group(['namespace'=>'Site'], function(){


Route::get('/', 'SiteController@index');
Route::get('/contato', 'SiteController@contato');
Route::get('/servicos', 'SiteController@servicos');
Route::get('/servicos/{id}', 'SiteController@categorias');
Route::get('/sobre', 'SiteController@sobre');
Route::get('/belasystem', 'SiteController@belasystem');

});


/* Exemplos de trabalhar com middleware - Dessa Forma quem está dentro desse
grupo, só poderá acessar estando 'autenticado'
Route::group(['namespace'=>'Site', 'middleware' => 'auth'], function(){


Route::get('/', 'SiteController@index');
Route::get('/contatos', 'SiteController@contatos');
Route::get('/servicos', 'SiteController@servicos');
Route::get('/servicos/{id}', 'SiteController@categorias');
Route::get('/sobre', 'SiteController@sobre');
Route::get('/belasystem', 'SiteController@belasystem');

});
*/

/* Exemplos de trabalhar com middleware - Dessa Forma quem está acessando a essa rota "contatos", so conseguira estando logado
Route::group(['namespace'=>'Site'], function(){


Route::get('/', 'SiteController@index');
Route::get('/contatos', 'SiteController@contatos')->middleware('auth');
Route::get('/servicos', 'SiteController@servicos');
Route::get('/servicos/{id}', 'SiteController@categorias');
Route::get('/sobre', 'SiteController@sobre');
Route::get('/belasystem', 'SiteController@belasystem');

});
*/