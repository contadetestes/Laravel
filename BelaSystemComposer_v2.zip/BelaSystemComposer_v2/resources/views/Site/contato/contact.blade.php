@extends('site.template.template1')

@section ('content')

<h1>Página de Contato</h1>

@endsection 