<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SiteController extends Controller
{   
    //public function __construct()
    //{
        // - Faz com que todos os metodos abaixo só possam ser usados se logar
        //$this-> middleware('auth');
        // - Faz com que apenas os metodos listados só possam ser usados se logar
        //$this->middleware('auth')
        //            ->only([
        //                'contatos',
        //                'categoria'
        //                ]);
        // - Faz com que apenas os metodos listados NÃO precisem ser logar para usar
        //$this->middleware('auth')
        //                ->except([
        //                    'index',
        //                    'contatos
        //                    ']);
    //}
    public function index()
    {
        $title = 'Espaço Afrodite - T'; 

        $xss   = '<script>alert("Ataque XSS");</script>';  

        $var1 = '123';

        $arrayData = [];

    	return view('site.home.index', compact('title', 'xss', 'var1', 'arrayData'));
    }

    public function contato()
    {
    	return view('site.contato.contact');
    }

    public function servicos()
    {
    	return view('site.servicos.services');
    }

    public function categorias($id)
    {
    	return "Testando Categorias: {$id}";
    }

    public function sobre()
    {
         $title = 'OI';  
    	return view('site.sobre.about',  compact('title'));
    }
    
    public function belasystem()
    {
    	return view('site.belasystem.system');
    }
     
}
