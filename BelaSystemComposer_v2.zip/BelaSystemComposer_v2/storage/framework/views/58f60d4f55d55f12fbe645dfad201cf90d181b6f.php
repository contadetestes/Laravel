<!DOCTYPE html>
<html>
<head>
	
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="Cícero Roniel" content="">
    <meta name="keywords" content="sites, web, desenvolvimento, salão, cabelos, alisamento, cabeleireira">
	
	<title>Espaço Afrodite </title>

	<link href="../css/carousel.css" rel="stylesheet">
	<link href="../css/app.css" rel="stylesheet">
	<link rel="shortcut icon" type="image/x-icon" href="imgs/favicon-16x16.png">
	<script src="../js/app.js"></script>
	<script src="/js/ie-emulation-modes-warning.js"></script>
	

</head>


<!-- NAVBAR -->
  <body>
    <div class="navbar-wrapper">
      <div class="container">

        <nav class="navbar navbar-inverse navbar-fixed-top "> 
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <img src="imgs/logo/logo02.png" alt="apoio" width="50" height= "50">
              <a class="navbar-brand" href="#">Espaço Afrodite</a>
              </div>

            <div id="navbar" class="navbar-collapse collapse">
            <li class="nav pull-right">
              <ul class="nav navbar-nav">
              	 
              	<a class="btn btn-danger navbar-right" href="projj.html" role="button" target="_blanck">BelaSystem</a>
				        <li class="nav pull-right"><a href="#sobre" class="strong"><span class="fa fa-id-card fa-2x"></span> Sobre</a></li>
                <li class="nav pull-right"><a href="servicos.html"" class="strong"><span class="fa fa-briefcase  fa-2x"></span> Serviços</a></li>
                <li  class="nav pull-right"><a href="contato.html" class="strong"><span class="fa fa-comments fa-2x"></span>Contato</a></li>
                <li  class="nav pull-right"><a href="index.html" class="strong"><span class="fa fa-comments fa-2x"></span>Home</a></li>
                <li  class="nav pull-right"><a href="testenavbar.html" class="strong"><span class="fa fa-comments fa-2x"></span>NavBarTeste</a></li>
                
                      </ul>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </nav>

      </div>
    </div>

    <!-- Carousel
    ================================================== -->
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="item active">
          <img class="first-slide" src="imgs/1200x800/loira_mexendo_nocabelo.png " alt="First slide">
          <div class="container">
            <div class="carousel-caption">
              <h1>Seja Loira!</h1>
              <p>Texto Sobre cabelos loiras</p>
              <p><a class="btn btn-lg btn-primary" href="#" role="button">Venha tratar seu loiro</a></p>
            </div>
          </div>
        </div>
        <div class="item">
          <img class="second-slide" src="imgs/1200x800/super_liso.jpeg" alt="Second slide">
          <div class="container">
            <div class="carousel-caption">
              <h1>Seja Liso!</h1>
              <p>Texto Sobre cabelos lisos</p>
              <p><a class="btn btn-lg btn-primary" href="#" role="button">Venha tratar seu liso</a></p>
            </div>
          </div>
        </div>
        <div class="item">
          <img class="third-slide" src="imgs/1200x800/Afro.jpg" alt="Third slide">
          <div class="container">
            <div class="carousel-caption">
              <h1>Seja Afro!</h1>
              <p>Texto Sobre cabelos afros</p>
              <p><a class="btn btn-lg btn-primary" href="#" role="button">Venha tratar seu afro</a></p>
            </div>
          </div>
        </div>
      </div>
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div><!-- /.carousel -->

    <div class="container marketing">

      <!-- Three columns of text below the carousel -->
      <div class="row">
        <div class="col-lg-4">
          <img class="img-circle" src="imgs/600x400/cortando.jpg" alt="Generic placeholder image" width="140" height="140">
          <h2>Cortes</h2>
          <p>Cortes especiais</p>
          <p><a class="btn btn-default" href="#" role="button">Clique aqui &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img class="img-circle" src="imgs/600x400/maquiando.jpg" alt="Generic placeholder image" width="140" height="140">
          <h2>Maquiagem</h2>
          <p>Maquiagem para dias especiais</p>
          <p><a class="btn btn-default" href="#" role="button">Clique aqui &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img class="img-circle" src="imgs/600x400/penteando.jpg" alt="Generic placeholder image" width="140" height="140">
          <h2>Penteados</h2>
          <p>Penteados para datas especiais</p>
          <p><a class="btn btn-default" href="#" role="button">Clique aqui &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->

        <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
        <h1 class="display-3">Hello, world!</h1>
        <p>This is a template for a simple marketing or informational website. It includes a large callout called a jumbotron and three supporting pieces of content. Use it as a starting point to create something more unique.</p>
        <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more &raquo;</a></p>
      </div>
    </div>

    <div class="container">
      <!-- Example row of columns -->
      <div class="row">
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
       </div>
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
          <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
        </div>
      </div>

      <hr>

<div class="jumbotron">
      <div class="container">
        <h1 class="display-3">Hello, world!</h1>
        <p>This is a template for a simple marketing or informational website. It includes a large callout called a jumbotron and three supporting pieces of content. Use it as a starting point to create something more unique.</p>
        <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more &raquo;</a></p>
      </div>
    </div>

    <div class="container">
      <!-- Example row of columns -->
      <div class="row">
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
       </div>
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
          <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
        </div>
      </div>

      <hr>

      <div class="jumbotron">
      <div class="container">
        <h1 class="display-3">Hello, world!</h1>
        <p>This is a template for a simple marketing or informational website. It includes a large callout called a jumbotron and three supporting pieces of content. Use it as a starting point to create something more unique.</p>
        <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more &raquo;</a></p>
      </div>
    </div>

    <div class="container">
      <!-- Example row of columns -->
      <div class="row">
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
       </div>
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
          <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
        </div>
      </div>

      <hr>
      <footer>
        <p>&copy; Company 2017</p>
      </footer>
    </div> <!-- /container -->
    <script src="app.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="app.js"></script>
</body>
</html>
