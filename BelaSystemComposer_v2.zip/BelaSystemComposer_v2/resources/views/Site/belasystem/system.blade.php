@extends('site.template.template1')

@section ('content')

<h1>Home Page do Site</h1>

@endsection 