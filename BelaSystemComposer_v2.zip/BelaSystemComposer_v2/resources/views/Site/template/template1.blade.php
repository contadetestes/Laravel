<!DOCTYPE html>
<html>
<head>
	<title>{{$title or 'Espaço Afrodite -'}}</title>
</head>
<body>

	@yield('content')

	@stack('scripts')

</body>
</html>