<?php $__env->startSection('content'); ?>

<h1>Home Page do Site - Aprendendo FOR, Else,, ForEach, ForElse</h1>
<button type="button" class="btn btn-lg btn-primary">Primary</button>
<?php echo e($xss); ?>


<?php if($var1 == '1234'): ?>

<p>É igual</p>
<?php else: ?>
<p>É diferente</p>

<?php endif; ?>

<?php if (! ( $var1 == '1234')): ?>
<p> Não é igual ... Unless</p>

<?php endif; ?>

<?php for( $i = 0; $i <10; $i++): ?>

<p>For: <?php echo e($i); ?></p>

<?php endfor; ?>



<?php $__empty_1 = true; $__currentLoopData = $arrayData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $array): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<p>Forelse: <?php echo e($array); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<p>Não será impresso pois n tem item</p>
<?php endif; ?>

<?php echo $__env->make('site.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?> 

<?php $__env->startPush('scripts'); ?>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<?php $__env->stopPush(); ?>
<?php echo $__env->make('site.template.template1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>