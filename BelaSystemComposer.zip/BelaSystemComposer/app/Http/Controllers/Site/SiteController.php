<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SiteController extends Controller
{
    public function index()
    {
    	return 'Home Page do Site';
    }
    public function contatos()
    {
    	return 'Pag contatos';
    }
    public function servicos()
    {
    	return 'Pag Serviços';
    }
    public function categorias($id)
    {
    	return "Testando Categorias: {$id}";
    }
    public function sobre()
    {
    	return 'Pag Sobre';
    }
    public function belasystem()
    {
    	return 'Sistema WEB';
    }
     
}
