<?php $__env->startSection('content'); ?>

<title>Oi</title>
<h1>Página Sobre</h1>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('site.template.template1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>