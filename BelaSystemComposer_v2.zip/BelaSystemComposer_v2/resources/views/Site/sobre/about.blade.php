@extends('site.template.template1')

@section ('content')

<title>Oi</title>
<h1>Página Sobre</h1>

@endsection 