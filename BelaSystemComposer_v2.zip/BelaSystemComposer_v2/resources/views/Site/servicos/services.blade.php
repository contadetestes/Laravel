@extends('site.template.template1')

@section ('content')

<h1>Página de serviços</h1>

@endsection 