<h1>Home Page do Site - Teste</h1>
<?php echo e($teste); ?>